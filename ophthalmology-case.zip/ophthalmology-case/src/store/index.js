import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    user: {
      uid: "",
      uname: "",
      accessToken: ""
    },
    isFullPageApp: false
  },
  mutations: {
    setFullPageApp(state, param) {
      state.isFullPageApp = param.isFullPageApp;
    },
    setLoginUser(state, param) {
      state.user.uid = param.uid;
      state.user.accessToken = param.accessToken;
    }
  },
  actions: {},
  modules: {}
});
