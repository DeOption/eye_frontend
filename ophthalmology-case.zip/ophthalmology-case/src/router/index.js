import Vue from "vue";
import VueRouter from "vue-router";
import Store from "@/store/index";
import CookieHelper from "cookie";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    redirect: "/list"
  },
  {
    path: "/list",
    name: "List",
    component: () => import("../views/List.vue")
  },
  {
    path: "/detail",
    name: "Detail",
    component: () => import("../views/Detail.vue")
  },
  {
    path: "/login",
    name: "Login",
    component: () => import("../views/Login.vue"),
    meta: {
      fullPage: true
    }
  },
  {
    path: "/register",
    name: "Register",
    component: () => import("../views/Register.vue"),
    meta: {
      fullPage: true
    }
  }
];

const router = new VueRouter({
  routes
});

router.beforeEach((to, from, next) => {
  let cookie = CookieHelper.parse(document.cookie);
  let { fullPage = false } = to.meta;
  Store.commit("setFullPageApp", { isFullPageApp: fullPage });
  if (cookie && cookie.eye_case_uid && cookie.eye_case_access_token) {
    Store.commit("setLoginUser", {
      uid: cookie.eye_case_uid,
      accessToken: cookie.eye_case_access_token
    });
    next();
  } else if (
    !Store.state.user.accessToken &&
    to.name !== "Login" &&
    to.name !== "Register"
  ) {
    router.push({ name: "Login" });
    next(false);
  } else {
    next();
  }
});

export default router;
