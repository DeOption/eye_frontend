<template>
  <div class="list">
    <a-input-group compact>
      <a-select
        v-model="type"
        placeholder="搜索类型"
        style="width: 150px;"
        :disabled="loading"
        @change="onTypeChange"
      >
        <a-select-option value="id">病例ID</a-select-option>
        <a-select-option value="id_number">身份证号</a-select-option>
        <a-select-option value="age">年龄</a-select-option>
        <a-select-option value="examination_lts_j">近方立体视</a-select-option>
        <a-select-option value="examination_lts_y">远方立体视</a-select-option>
        <a-select-option value="examination_slj_zj_near">
          视近（直角）
        </a-select-option>
        <a-select-option value="examination_slj_zj_far">
          视远（直角）
        </a-select-option>
        <a-select-option value="examination_slj_dy_near">
          视近（等腰）
        </a-select-option>
        <a-select-option value="examination_slj_dy_far">
          视远（等腰）
        </a-select-option>
        <a-select-option value="examination_slj_cz">直角三棱镜</a-select-option>
        <a-select-option value="examination_slj_cz_z">
          垂直三棱镜
        </a-select-option>
        <a-select-option value="k_method">k法</a-select-option>
        <a-select-option value="latent_strabismus">隐斜视</a-select-option>
        <a-select-option value="Internal_strabismus">内斜视</a-select-option>
        <a-select-option value="Exotropia">外斜视</a-select-option>
        <a-select-option value="A_V">A⁃V斜视</a-select-option>
        <a-select-option value="V">垂直旋转性斜视</a-select-option>
        <a-select-option value="S">特殊类型斜视</a-select-option>
        <a-select-option value="PS">中枢性麻痹性斜视</a-select-option>
        <a-select-option value="N">眼球震颤</a-select-option>
        <a-select-option value="other">其他</a-select-option>
      </a-select>
      <a-input-search
        v-model="search"
        placeholder="搜索关键字"
        enter-button
        style="width: 300px; margin-bottom: 10px;"
        :disabled="loading"
        @search="getCaseList"
      />
    </a-input-group>
    <a-table
      bordered
      size="small"
      :columns="columns"
      :data-source="rows"
      :pagination="false"
      :loading="loading"
      :scroll="{ x: 1285 }"
      :row-key="record => record.id"
    >
      <template slot="operation" slot-scope="text, record">
        <a-button type="primary" @click="onDetailClick(record)">查看</a-button>
      </template>
    </a-table>
    <a-pagination
      class="pagination"
      size="small"
      :current-page="currentPage"
      :page-size="pageSize"
      :total="total"
      :show-total="total => `共 ${total} 条记录`"
      show-size-changer
      show-quick-jumper
      @change="onCurrentPageChange"
      @showSizeChange="onPageSizeChange"
    />
  </div>
</template>
<script>
import { mapState } from "vuex";
import _ from "underscore";

export default {

  name: "List",
  data() {
    return {
      type: "id",
      search: "",
      loading: false,
      columns: [],
      rows: [],
      currentPage: 1,
      pageSize: 10,
      total: 0
    };
  },
  computed: {
    ...mapState({
      user: state => state.user
    })
  },
  created() {
    this.getCaseList();
  },
  methods: {
    getColumns() {
      return [
        {
          title: "病例ID",
          dataIndex: "id",
          key: "id",
          width: 200,
          scopedSlots: { customRender: "id" }
        },
        {
          title: "用户姓名",
          dataIndex: "user_name",
          key: "user_name",
          ellipsis: true,
          scopedSlots: { customRender: "user_name" }
        },
        {
          title: "手机号码",
          dataIndex: "phone_number",
          key: "phone_number",
          ellipsis: true,
          scopedSlots: { customRender: "phone_number" }
        },
        {
          title: "随访时间",
          dataIndex: "suifang",
          key: "suifang",
          width: 200,
          ellipsis: true,
          scopedSlots: { customRender: "suifang" }
        },
        {
          title: "创建时间",
          dataIndex: "create_time",
          key: "create_time",
          width: 200,
          ellipsis: true,
          scopedSlots: { customRender: "create_time" }
        },
        {
          title: "修改时间",
          dataIndex: "modify_time",
          key: "modify_time",
          width: 200,
          ellipsis: true,
          scopedSlots: { customRender: "modify_time" }
        },
        {
          title: "操作",
          dataIndex: "operation",
          key: "operation",
          width: 85,
          fixed: "right",
          scopedSlots: { customRender: "operation" }
        }
      ];
    },
    getCaseList() {
      let param = {
        offset: this.currentPage,
        size: this.pageSize
      };
      if (this.search) {
        param[this.type] = this.search;
      }
      this.loading = true;
      this.$api("getCaseList", param, { slient: true, allowNoneZero: true })
        .then(response => {
          if (response) {
            if (response.return_code !== 0) {
              this.$message.error(response.return_msg);
            } else {
              this.columns = this.getColumns();
              this.rows = response.case_data.map(item => {
                return _.extend(item, {
                  suifang: item.suifang.replace("T", " "),
                  create_time: item.create_time.replace("T", " "),
                  modify_time: item.modify_time.replace("T", " ")
                });
              });
              this.total = response.total;
            }
          } else {
            this.$message.error("请求错误，请重试！");
          }
          return Promise.resolve();
        })
        .then(() => {
          this.loading = false;
        });
    },
    onDetailClick(record) {
      this.$router.push({ name: "Detail", query: { id: record.id } });
    },
    onCurrentPageChange(page) {
      this.currentPage = page;
      this.getCaseList();
    },
    onPageSizeChange(page, size) {
      this.pageSize = size;
      this.getCaseList();
    },
    onTypeChange() {
      this.search = "";
    }
  }
};
</script>
<style lang="stylus" scoped>
.list
  min-height 750px
.pagination
  float right
  margin-top 10px
</style>
