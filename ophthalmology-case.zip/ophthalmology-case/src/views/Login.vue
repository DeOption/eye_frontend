<template>
  <div class="login" style="min-height: 650px;">
    <a-card hoverable class="content">
      <div class="title">登录</div>
      <a-tabs :default-active-key="1" @change="tabsChange">
        <a-tab-pane :key="1" tab="账户密码登录">
          <div class="row" style="margin-top: 10px;">
            <div class="label">用户名称:</div>
            <a-input
              v-model="userName"
              style="width: 370px;"
              size="large"
              placeholder="请输入用户名称/手机号/邮箱账号"
              :disabled="loading"
            >
              <a-icon slot="prefix" type="user" />
            </a-input>
          </div>
          <div class="row">
            <div class="label">用户密码:</div>
            <a-input
              v-model="userPassword"
              style="width: 370px;"
              size="large"
              type="password"
              placeholder="请输入用户密码"
              :disabled="loading"
            >
              <a-icon slot="prefix" type="lock" />
            </a-input>
          </div>
        </a-tab-pane>
      </a-tabs>
      <span class="footer">
        <a-checkbox
          style="margin-top: 5px;"
          :checked="autoLogin"
          @change="handleAutoLogin"
          >1天内免密登录</a-checkbox
        >
<!--        <a-button-->
<!--          style="margin-bottom: 10px; float: right;"-->
<!--          type="link"-->
<!--          @click="handleForgetPassword"-->
<!--          >忘记密码?</a-button-->
<!--        >-->
        <a-button
          style="margin-bottom: 10px; width: 100%;"
          size="large"
          type="primary"
          :loading="loading"
          @click="login"
          >登录</a-button
        >
        <!-- <span>
          <span>其他登录方式:</span>
          <a-button
            style="margin-left: 5px;"
            size="small"
            shape="circle"
            icon="wechat"
          />
          <a-button
            style="margin-left: 5px;"
            size="small"
            shape="circle"
            icon="qq"
          />
          <a-button
            style="margin-left: 5px;"
            size="small"
            shape="circle"
            icon="weibo"
          />
        </span> -->
        <router-link :to="{ name: 'Register' }">
<!--          <a-button style="float: left; margin-bottom: 10px;" type="link">-->
<!--            <a-icon type="user-add" /> 注册账户-->
<!--          </a-button>-->
        </router-link>
        <div class="copyright">
          Copyright @2020-{{ new Date().getFullYear() }} 价值眼
        </div>
      </span>
    </a-card>
  </div>
</template>
<script>
import commonUtils from "@/common/utils";
export default {
  name: "Login",
  data() {
    return {
      loading: false,
      userName: "",
      userPassword: "",
      userMobile: "",
      userCaptcha: "",
      tabs: 1,
      autoLogin: false
    };
  },
  methods: {
    tabsChange(key) {
      this.tabs = key;
    },
    handleForgetPassword() {
      this.$message.info("请联系管理员重新验证身份!");
    },
    login() {
      let param = {
        username: this.userName,
        password: this.userPassword
      };
      this.loading = true;
      this.$api("userLogin", param, { slient: true, allowNoneZero: true })
        .then(response => {
          if (response) {
            if (response.return_code !== 0) {
              this.$message.error(response.return_msg);
            } else {
              this.$message.success("登录成功！");
              this.$store.commit("setLoginUser", {
                uid: response.uid,
                accessToken: response.access_token
              });
              if (this.autoLogin) {
                commonUtils.setCookie("eye_case_uid", response.uid);
                commonUtils.setCookie(
                  "eye_case_access_token",
                  response.access_token
                );
              }
              this.$router.push({ name: "List" });
            }
          } else {
            this.$message.error("请求错误，请重试！");
          }
          return Promise.resolve();
        })
        .then(() => {
          this.loading = false;
        });
    },
    handleAutoLogin(e) {
      this.autoLogin = e.target.checked;
    }
  }
};
</script>
<style lang="stylus" scoped>
.login >>> .ant-tabs-nav
  margin-left 165px
.login
  width 100%
  height 500px
  display flex
  justify-content center
  align-items center
  background-image url(https://gw.alipayobjects.com/zos/rmsportal/TVYTbAXWheQpRcWDaDMu.svg)
  background-repeat no-repeat
  background-position center 110px
  background-size 100%
  .row
    height 60px
    line-height 60px
    .label
      width 80px
      font-weight bold
      display inline-block
  .title
    width 100%
    margin-top 25px
    margin-bottom 35px
    color rgba(0, 0, 0, 0.85)
    font-weight 600
    font-size 33px
    font-family Avenir, helvetica neue, Arial, Helvetica, sans-serif
    text-align center
  .content
    width 500px
    height 600px
    .footer
      margin-top 20px
  .copyright
    margin-top 130px
    text-align center
    color rgba(0,0,0,.45)
    font-size 14px
</style>
