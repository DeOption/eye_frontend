<template>
  <div class="detail">
    <template v-if="viewLoading">
      <a-icon type="loading" /> 数据加载中...
    </template>
    <template v-else>
      <a-page-header class="titles" title="眼科病例" sub-title="眼科病例详情" />
      <a-descriptions
        title="基本信息"
        :column="1"
        bordered
        class="descriptions"
      >
        <a-descriptions-item label="* 数据类别">
          <a-radio-group name="dataType" v-model="info.base_info.data_type">
            <a-radio value="门诊患者">门诊患者</a-radio>
            <a-radio value="住院患者">住院患者</a-radio>
            <a-radio value="幼儿园筛查">幼儿园筛查</a-radio>
          </a-radio-group>
        </a-descriptions-item>
        <a-descriptions-item label="* 姓名">
          <a-input
            v-model="info.base_info.user_name"
            placeholder="请输入"
          ></a-input>
        </a-descriptions-item>
        <a-descriptions-item label="性别">
          <a-radio-group name="sexType" v-model="info.base_info.sex">
            <a-radio value="男">男</a-radio>
            <a-radio value="女">女</a-radio>
          </a-radio-group>
        </a-descriptions-item>
        <a-descriptions-item label="年龄">
          <a-select
            v-model="info.base_info.age"
            placeholder="请选择"
            style="width: 100%;"
          >
            <a-select-option value="无">无</a-select-option>
            <a-select-option value="one_month">1个月</a-select-option>
            <a-select-option value="two_months">2个月</a-select-option>
            <a-select-option value="three_months">3个月</a-select-option>
            <a-select-option value="four_months">4个月</a-select-option>
            <a-select-option value="five_months">5个月</a-select-option>
            <a-select-option value="six_months">6个月</a-select-option>
            <a-select-option value="seven_months">7个月</a-select-option>
            <a-select-option value="eight_months">8个月</a-select-option>
            <a-select-option value="nine_months">9个月</a-select-option>
            <a-select-option value="ten_months">10个月</a-select-option>
            <a-select-option value="eleven_months">11个月</a-select-option>
            <a-select-option v-for="day of 80" :key="day" :value="String(day)">
              {{ day }}
            </a-select-option>
          </a-select>
        </a-descriptions-item>
        <a-descriptions-item label="身份证号">
          <a-input v-model="info.base_info.id_number" placeholder="请输入" />
        </a-descriptions-item>
        <a-descriptions-item label="手机号">
          <a-input v-model="info.base_info.phone_number" placeholder="请输入" />
        </a-descriptions-item>
        <a-descriptions-item label="登记号/顺序号">
          <a-input v-model="info.base_info.order_number" placeholder="请输入" />
        </a-descriptions-item>
      </a-descriptions>
      <a-descriptions title="病史" :column="1" bordered class="descriptions">
        <a-descriptions-item label="现病史">
          <a-descriptions :column="1" bordered>
            <a-descriptions-item label="斜视年龄">
              <a-input
                v-model="info.medical_history.now_age"
                placeholder="请输入"
              ></a-input>
            </a-descriptions-item>
            <a-descriptions-item label="歪头">
              <a-radio-group
                name="tiltHeadType"
                v-model="info.medical_history.now_wt"
              >
                <a-radio :value="true">有</a-radio>
                <a-radio :value="false">无</a-radio>
              </a-radio-group>
            </a-descriptions-item>
            <a-descriptions-item label="复视">
              <a-radio-group
                name="diplopiaType"
                v-model="info.medical_history.now_fs"
              >
                <a-radio :value="true">有</a-radio>
                <a-radio :value="false">无</a-radio>
              </a-radio-group>
            </a-descriptions-item>
          </a-descriptions>
        </a-descriptions-item>
        <a-descriptions-item label="手术史">
          <a-radio-group
            name="historySurgeryType"
            v-model="info.medical_history.surgery_history"
          >
            <a-radio :value="true">有</a-radio>
            <a-radio :value="false">无</a-radio>
          </a-radio-group>
        </a-descriptions-item>
        <a-descriptions-item
          v-if="info.medical_history.surgery_history"
          label="手术史详情"
        >
          <a-input
            v-model="info.medical_history.surgery_history_edit"
            placeholder="请输入"
          />
        </a-descriptions-item>
        <a-descriptions-item label="戴镜史">
          <a-select
            v-model="info.medical_history.glasses_history"
            style="width: 100%;"
            placeholder="请选择"
          >
            <a-select-option value="无">无</a-select-option>
            <a-select-option value="0">0</a-select-option>
            <a-select-option
              v-for="item of 80"
              :key="item"
              :value="String(item)"
            >
              {{ item }}
            </a-select-option>
          </a-select>
        </a-descriptions-item>
        <a-descriptions-item label="弱视治疗史">
          <a-radio-group
            name="historyAmblyopiaType"
            v-model="info.medical_history.amblyopia_history"
          >
            <a-radio :value="true">有</a-radio>
            <a-radio :value="false">无</a-radio>
          </a-radio-group>
        </a-descriptions-item>
        <a-descriptions-item label="家族史">
          <a-radio-group
            name="historyFamilyType"
            v-model="info.medical_history.home_history"
          >
            <a-radio :value="true">有</a-radio>
            <a-radio :value="false">无</a-radio>
          </a-radio-group>
        </a-descriptions-item>
        <a-descriptions-item label="生产史">
          <a-radio-group
            name="historyProductionType"
            v-model="info.medical_history.born_history"
          >
            <a-radio :value="true">有</a-radio>
            <a-radio :value="false">无</a-radio>
          </a-radio-group>
        </a-descriptions-item>
      </a-descriptions>
      <a-descriptions title="检查" :column="1" bordered class="descriptions">
        <a-descriptions-item label="裸眼视力">
          <a-descriptions :column="1" bordered>
            <a-descriptions-item label="右眼">
              <a-select
                v-model="info.examination.examination_nv.right"
                style="width: 100%;"
                placeholder="请选择"
              >
                <a-select-option value="无">无</a-select-option>
                <a-select-option value="NLP">NLP</a-select-option>
                <a-select-option value="LP">LP</a-select-option>
                <a-select-option value="HM">HM</a-select-option>
                <a-select-option value="CF">CF</a-select-option>
                <a-select-option value="0.1">0.1</a-select-option>
                <a-select-option value="0.15">0.15</a-select-option>
                <a-select-option value="0.2">0.2</a-select-option>
                <a-select-option value="0.3">0.3</a-select-option>
                <a-select-option value="0.4">0.4</a-select-option>
                <a-select-option value="0.5">0.5</a-select-option>
                <a-select-option value="0.6">0.6</a-select-option>
                <a-select-option value="0.8">0.8</a-select-option>
                <a-select-option value="1.0">1.0</a-select-option>
                <a-select-option value="no">不懂</a-select-option>
              </a-select>
            </a-descriptions-item>
            <a-descriptions-item label="左眼">
              <a-select
                v-model="info.examination.examination_nv.left"
                style="width: 100%;"
                placeholder="请选择"
              >
                <a-select-option value="无">无</a-select-option>
                <a-select-option value="NLP">NLP</a-select-option>
                <a-select-option value="LP">LP</a-select-option>
                <a-select-option value="HM">HM</a-select-option>
                <a-select-option value="CF">CF</a-select-option>
                <a-select-option value="0.1">0.1</a-select-option>
                <a-select-option value="0.15">0.15</a-select-option>
                <a-select-option value="0.2">0.2</a-select-option>
                <a-select-option value="0.3">0.3</a-select-option>
                <a-select-option value="0.4">0.4</a-select-option>
                <a-select-option value="0.5">0.5</a-select-option>
                <a-select-option value="0.6">0.6</a-select-option>
                <a-select-option value="0.8">0.8</a-select-option>
                <a-select-option value="1.0">1.0</a-select-option>
                <a-select-option value="no">不懂</a-select-option>
              </a-select>
            </a-descriptions-item>
          </a-descriptions>
        </a-descriptions-item>
        <a-descriptions-item label="矫正视力">
          <a-descriptions :column="1" bordered>
            <a-descriptions-item label="右眼">
              <a-select
                v-model="info.examination.examination_corrected_visual.right"
                style="width: 100%;"
                placeholder="请选择"
              >
                <a-select-option value="无">无</a-select-option>
                <a-select-option value="NLP">NLP</a-select-option>
                <a-select-option value="LP">LP</a-select-option>
                <a-select-option value="HM">HM</a-select-option>
                <a-select-option value="CF">CF</a-select-option>
                <a-select-option value="0.1">0.1</a-select-option>
                <a-select-option value="0.15">0.15</a-select-option>
                <a-select-option value="0.2">0.2</a-select-option>
                <a-select-option value="0.3">0.3</a-select-option>
                <a-select-option value="0.4">0.4</a-select-option>
                <a-select-option value="0.5">0.5</a-select-option>
                <a-select-option value="0.6">0.6</a-select-option>
                <a-select-option value="0.8">0.8</a-select-option>
                <a-select-option value="1.0">1.0</a-select-option>
              </a-select>
            </a-descriptions-item>
            <a-descriptions-item label="左眼">
              <a-select
                v-model="info.examination.examination_corrected_visual.left"
                style="width: 100%;"
                placeholder="请选择"
              >
                <a-select-option value="无">无</a-select-option>
                <a-select-option value="NLP">NLP</a-select-option>
                <a-select-option value="LP">LP</a-select-option>
                <a-select-option value="HM">HM</a-select-option>
                <a-select-option value="CF">CF</a-select-option>
                <a-select-option value="0.1">0.1</a-select-option>
                <a-select-option value="0.15">0.15</a-select-option>
                <a-select-option value="0.2">0.2</a-select-option>
                <a-select-option value="0.3">0.3</a-select-option>
                <a-select-option value="0.4">0.4</a-select-option>
                <a-select-option value="0.5">0.5</a-select-option>
                <a-select-option value="0.6">0.6</a-select-option>
                <a-select-option value="0.8">0.8</a-select-option>
                <a-select-option value="1.0">1.0</a-select-option>
              </a-select>
            </a-descriptions-item>
          </a-descriptions>
        </a-descriptions-item>
        <a-descriptions-item label="电脑验光">
          <a-descriptions :column="1" bordered>
            <a-descriptions-item label="右眼">
              <a-input-number
                v-model="info.examination.examination_co.right.ds"
                :min="-15"
                :max="15"
                :step="0.25"
              />DS
              <a-input-number
                v-model="info.examination.examination_co.right.dc"
                :min="-8"
                :max="8"
                :step="0.25"
              />DC
              <a-input
                v-model="info.examination.examination_co.right.a"
                style="width: 100px;"
              />A
            </a-descriptions-item>
            <a-descriptions-item label="左眼">
              <a-input-number
                v-model="info.examination.examination_co.left.ds"
                :min="-15"
                :max="15"
                :step="0.25"
              />DS
              <a-input-number
                v-model="info.examination.examination_co.left.dc"
                :min="-8"
                :max="8"
                :step="0.25"
              />DC
              <a-input
                v-model="info.examination.examination_co.left.a"
                style="width: 100px;"
              />A
            </a-descriptions-item>
          </a-descriptions>
        </a-descriptions-item>
        <a-descriptions-item label="检影验光">
          <a-descriptions :column="1" bordered>
            <a-descriptions-item label="右眼">
              <a-input-number
                v-model="info.examination.examination_ro.right.ds"
                :min="-15"
                :max="15"
                :step="0.25"
              />DS
              <a-input-number
                v-model="info.examination.examination_ro.right.dc"
                :min="-8"
                :max="8"
                :step="0.25"
              />DC
              <a-input
                v-model="info.examination.examination_ro.right.a"
                style="width: 100px;"
              />A
            </a-descriptions-item>
            <a-descriptions-item label="左眼">
              <a-input-number
                v-model="info.examination.examination_ro.left.ds"
                :min="-15"
                :max="15"
                :step="0.25"
              />DS
              <a-input-number
                v-model="info.examination.examination_ro.left.dc"
                :min="-8"
                :max="8"
                :step="0.25"
              />DC
              <a-input
                v-model="info.examination.examination_ro.left.a"
                style="width: 100px;"
              />A
            </a-descriptions-item>
          </a-descriptions>
        </a-descriptions-item>
        <a-descriptions-item label="同视机">
          <a-descriptions :column="1" bordered>
            <a-descriptions-item label="同时视">
              <a-radio-group
                name="sameType"
                v-model="info.examination.examination_tsj.examination_tsj_tss"
              >
                <a-radio :value="true">有</a-radio>
                <a-radio :value="false">无</a-radio>
              </a-radio-group>
            </a-descriptions-item>
            <a-descriptions-item
              v-if="info.examination.examination_tsj.examination_tsj_tss"
              label="同时视值类型"
            >
              <a-radio-group
                name="sameTypeNone"
                v-model="examination_tsj_tss_none"
              >
                <a-radio :value="true" @change="inputnull1">水平值</a-radio>
                <a-radio :value="false" @change="inputnull2">垂直值</a-radio>
              </a-radio-group>
<!--              水平-->
              <a-input
                v-if="examination_tsj_tss_none"
                v-model="
                  // eslint-disable-next-line prettier/prettier
                  info.examination.examination_tsj.examination_tsj_tss_sp
                "
                style="width: 100px"
                placeholder="请输入"
              ></a-input>
<!--              //垂直-->
              <template v-else-if="!examination_tsj_tss_none">
                <a-select
                  v-model="
                    // eslint-disable-next-line prettier/prettier
                    info.examination.examination_tsj.examination_tsj_tss_cz
                  "
                  placeholder="请选择"
                >
                  <a-select-option value="无">无</a-select-option>
                  <a-select-option value="R_L">R/L</a-select-option>
                  <a-select-option value="L_R">L/R</a-select-option>
                  <a-select-option value="NO">NO</a-select-option>
                </a-select>
                <a-input
                  v-if="
                    // eslint-disable-next-line prettier/prettier
                    info.examination.examination_tsj.examination_tsj_tss_cz !== 'NO'
                  "
                  v-model="
                    // eslint-disable-next-line prettier/prettier
                    info.examination.examination_tsj.examination_tsj_tss_cs_z
                  "
                  style="width: 100px;margin-left: 10px;"
                  placeholder="请输入"
                ></a-input>
              </template>
            </a-descriptions-item>
          </a-descriptions>
        </a-descriptions-item>
        <a-descriptions-item label="立体视">
          <a-descriptions :column="1" bordered>
            <a-descriptions-item label="近方随机点立体视">
              <a-select
                v-model="info.examination.examination_lts.examination_lts_j"
                style="width: 100%;"
                placeholder="请选择"
              >
                <a-select-option value="No">无</a-select-option>
                <a-select-option value="20">20</a-select-option>
                <a-select-option value="40">40</a-select-option>
                <a-select-option value="60">60</a-select-option>
                <a-select-option value="100">100</a-select-option>
                <a-select-option value="200">200</a-select-option>
                <a-select-option value="400">400</a-select-option>
                <a-select-option value="800">800</a-select-option>
                <a-select-option value="1000">1000</a-select-option>
              </a-select>
            </a-descriptions-item>
            <a-descriptions-item label="远方随机点立体视">
              <a-select
                v-model="info.examination.examination_lts.examination_lts_y"
                style="width: 100%;"
                placeholder="请选择"
              >
                <a-select-option value="No">无</a-select-option>
                <a-select-option value="20">20</a-select-option>
                <a-select-option value="40">40</a-select-option>
                <a-select-option value="60">60</a-select-option>
                <a-select-option value="100">100</a-select-option>
                <a-select-option value="200">200</a-select-option>
                <a-select-option value="400">400</a-select-option>
                <a-select-option value="800">800</a-select-option>
                <a-select-option value="1000">1000</a-select-option>
              </a-select>
            </a-descriptions-item>
          </a-descriptions>
        </a-descriptions-item>
        <a-descriptions-item label="控制力">
          <a-select
            v-model="info.examination.examination_control.examination_Control"
            style="width: 100%;"
            placeholder="请选择"
          >
            <a-select-option value="No">无</a-select-option>
            <a-select-option value="0">0</a-select-option>
            <a-select-option value="1">1</a-select-option>
            <a-select-option value="2">2</a-select-option>
            <a-select-option value="3">3</a-select-option>
            <a-select-option value="4">4</a-select-option>
            <a-select-option value="5">5</a-select-option>
          </a-select>
        </a-descriptions-item>
        <a-descriptions-item label="角膜映光(左眼)">
          <a-radio-group
            v-model="examination_cornea_left_type"
            placeholder="请选择"
          >
            <a-radio :value="true" @change="jmyglnull1">水平值</a-radio>
            <a-radio :value="false" @change="jmyglnull2">垂直值</a-radio>
          </a-radio-group>
<!--          水平-->
          <a-select
            v-if="examination_cornea_left_type"
            v-model="
              info.examination.examination_cornea.left.examination_cornea_sp
            "
            style="width: 100px; margin-left: 10px;"
            placeholder="请选择"
          >
            <a-select-option value="无">无</a-select-option>
            <a-select-option value=">45">>45</a-select-option>
            <a-select-option
              v-for="item of 19"
              :key="item"
              :value="`${item * 5 - 50}`"
            >
              {{ item * 5 - 50 }}
            </a-select-option>
            <a-select-option value="<-45">&lt;-45</a-select-option>
          </a-select>
<!--          垂直-->
          <template v-else-if="!examination_cornea_left_type">
            <a-select
              v-model="
                // eslint-disable-next-line prettier/prettier
                info.examination.examination_cornea.left.examination_cornea_cz
              "
              style="margin-left: 10px;"
              placeholder="请选择"
            >
              <a-select-option value="无">无</a-select-option>
              <a-select-option value="R_L">R/L</a-select-option>
              <a-select-option value="L_R">L/R</a-select-option>
              <a-select-option value="NO">NO</a-select-option>
            </a-select>
            <a-select
              v-if="
                // eslint-disable-next-line prettier/prettier
                info.examination.examination_cornea.left.examination_cornea_cz !== 'NO'
              "
              v-model="
                info.examination.examination_cornea.left.examination_cornea_cz_z
              "
              style="width: 100px; margin-left: 10px;"
              placeholder="请选择"
            >
              <a-select-option value="无">无</a-select-option>
              <a-select-option value=">45">>45</a-select-option>
              <a-select-option
                v-for="item of 19"
                :key="item"
                :value="`${item * 5 - 50}`"
              >
                {{ item * 5 - 50 }}
              </a-select-option>
              <a-select-option value="<-45">&lt;-45</a-select-option>
            </a-select>
          </template>
        </a-descriptions-item>
        <a-descriptions-item label="角膜映光(右眼)">
          <a-radio-group
            v-model="examination_cornea_right_type"
            placeholder="请选择"
          >
            <a-radio :value="true" @change="jmygrnull1">水平值</a-radio>
            <a-radio :value="false" @change="jmygrnull2">垂直值</a-radio>
          </a-radio-group>
          <a-select
            v-if="examination_cornea_right_type"
            v-model="
              info.examination.examination_cornea.right.examination_cornea_sp
            "
            style="width: 100px; margin-left: 10px;"
            placeholder="请选择"
          >
            <a-select-option value="无">无</a-select-option>
            <a-select-option value=">45">>45</a-select-option>
            <a-select-option
              v-for="item of 19"
              :key="item"
              :value="`${item * 5 - 50}`"
            >
              {{ item * 5 - 50 }}
            </a-select-option>
            <a-select-option value="<-45">&lt;-45</a-select-option>
          </a-select>
          <template v-else-if="!examination_cornea_right_type">
            <a-select
              v-model="
                // eslint-disable-next-line prettier/prettier
                info.examination.examination_cornea.right.examination_cornea_cz
              "
              style="margin-left: 10px;"
              placeholder="请选择"
            >
              <a-select-option value="无">无</a-select-option>
              <a-select-option value="R_L">R/L</a-select-option>
              <a-select-option value="L_R">L/R</a-select-option>
              <a-select-option value="NO">NO</a-select-option>
            </a-select>
            <a-select
              v-if="
                // eslint-disable-next-line prettier/prettier
                info.examination.examination_cornea.right.examination_cornea_cz !== 'NO'
              "
              v-model="
                // eslint-disable-next-line prettier/prettier
                info.examination.examination_cornea.right.examination_cornea_cz_z
              "
              style="width: 100px; margin-left: 10px;"
              placeholder="请选择"
            >
              <a-select-option value="无">无</a-select-option>
              <a-select-option value=">45">>45</a-select-option>
              <a-select-option
                v-for="item of 19"
                :key="item"
                :value="`${item * 5 - 50}`"
              >
                {{ item * 5 - 50 }}
              </a-select-option>
              <a-select-option value="<-45">&lt;-45</a-select-option>
            </a-select>
          </template>
        </a-descriptions-item>
        <a-descriptions-item label="三棱镜">
          <a-descriptions :column="1" bordered>
            <a-descriptions-item label="视近（直角）">
              <a-select
                v-model="
                  info.examination.examination_slj.examination_slj_zj_near
                "
                style="width: 100%;"
                placeholder="请选择"
              >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                  v-for="item of 61"
                  :key="item"
                  :value="`${item * 5 - 155}`"
                >
                  {{ item * 5 - 155 }}
                </a-select-option>
              </a-select>
            </a-descriptions-item>
            <a-descriptions-item label="视远（直角）">
              <a-select
                v-model="
                  info.examination.examination_slj.examination_slj_zj_far
                "
                style="width: 100%;"
                placeholder="请选择"
              >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                  v-for="item of 61"
                  :key="item"
                  :value="`${item * 5 - 155}`"
                >
                  {{ item * 5 - 155 }}
                </a-select-option>
              </a-select>
            </a-descriptions-item>
            <a-descriptions-item label="视近（等腰）">
              <a-select
                v-model="
                  info.examination.examination_slj.examination_slj_dy_near
                "
                style="width: 100%;"
                placeholder="请选择"
              >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                  v-for="item of 61"
                  :key="item"
                  :value="`${item * 5 - 155}`"
                >
                  {{ item * 5 - 155 }}
                </a-select-option>
              </a-select>
            </a-descriptions-item>
            <a-descriptions-item label="视远（等腰）">
              <a-select
                v-model="
                  info.examination.examination_slj.examination_slj_dy_far
                "
                style="width: 100%;"
                placeholder="请选择"
              >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                  v-for="item of 61"
                  :key="item"
                  :value="`${item * 5 - 155}`"
                >
                  {{ item * 5 - 155 }}
                </a-select-option>
              </a-select>
            </a-descriptions-item>
            <a-descriptions-item label="垂直三棱镜">
              <a-select
                v-model="info.examination.examination_slj.examination_slj_cz"
                style="width: 100px;margin-right: 10px;"
                placeholder="请选择"
              >
                <a-select-option value="无">无</a-select-option>
                <a-select-option value="R_L">R/L</a-select-option>
                <a-select-option value="L_R">L/R</a-select-option>
              </a-select>
              <a-select
                v-model="info.examination.examination_slj.examination_slj_cz_z"
                style="width: 100px;"
                placeholder="请选择"
              >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                  v-for="item of 46"
                  :key="item"
                  :value="`${item + 4}`"
                >
                  {{ item + 4 }}
                </a-select-option>
              </a-select>
            </a-descriptions-item>
            <a-descriptions-item label="K法">
              <a-select
                v-model="info.examination.examination_slj.k_method"
                style="width: 100%;"
                placeholder="请选择"
              >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                  v-for="item of 61"
                  :key="item"
                  :value="`${item * 5 - 155}`"
                >
                  {{ item * 5 - 155 }}
                </a-select-option>
              </a-select>
            </a-descriptions-item>
          </a-descriptions>
        </a-descriptions-item>
        <a-descriptions-item label="眼球运动">
          <a-descriptions :column="1" bordered>
            <a-descriptions-item label="眼球运动右眼">
              <a-checkbox-group
                v-model="examination_eyeballsport_right"
                name="movementRightEyeType"
              />
              <p>正常
                <a-select
                    v-model="info.examination.examination_eyeballsport.right.normal"
                    style="width: 100px;margin-right: 10px;"
                    placeholder="请选择"
                >
                  <a-select-option :value="true">是</a-select-option>
                  <a-select-option :value="false">否</a-select-option>
                </a-select>
              </p>
              <p v-if="info.examination.examination_eyeballsport.right.normal==false">外直肌
                <a-select
                    v-model="
                    info.examination.examination_eyeballsport.right.external_rectus
                  "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="请选择"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                  </a-select>
                </p>
              <p v-if="info.examination.examination_eyeballsport.right.normal==false">内直肌
                <a-select

                    v-model="
                  info.examination.examination_eyeballsport.right.internal_rectus
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="内直肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.examination.examination_eyeballsport.right.normal==false">上直肌
                <a-select
                    v-model="
                  info.examination.examination_eyeballsport.right.upper_rectus
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="上直肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.examination.examination_eyeballsport.right.normal==false">下直肌
                <a-select
                    v-model="
                  info.examination.examination_eyeballsport.right.lower_rectus
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="下直肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.examination.examination_eyeballsport.right.normal==false">上斜肌
                <a-select
                    v-model="
                  info.examination.examination_eyeballsport.right.upper_oblique
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="上斜肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.examination.examination_eyeballsport.right.normal==false">下斜肌
                <a-select
                    v-model="
                  info.examination.examination_eyeballsport.right.lower_oblique
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="下斜肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>

            </a-descriptions-item>
            <a-descriptions-item label="眼球运动左眼">
              <a-checkbox-group
                v-model="examination_eyeballsport_left"
                name="movementLeftEyeType"
              />
              <p>正常
                <a-select
                    v-model="info.examination.examination_eyeballsport.left.normal"
                    style="width: 100px;margin-right: 10px;"
                    placeholder="请选择"
                >
                  <a-select-option :value="true">是</a-select-option>
                  <a-select-option :value="false">否</a-select-option>
                </a-select>
              </p>
              <p v-if="info.examination.examination_eyeballsport.left.normal==false">外直肌
                <a-select
                    v-model="
                    info.examination.examination_eyeballsport.left.external_rectus
                  "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="请选择"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.examination.examination_eyeballsport.left.normal==false">内直肌
                <a-select

                    v-model="
                  info.examination.examination_eyeballsport.left.internal_rectus
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="内直肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.examination.examination_eyeballsport.left.normal==false">上直肌
                <a-select
                    v-model="
                  info.examination.examination_eyeballsport.left.upper_rectus
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="上直肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.examination.examination_eyeballsport.left.normal==false">下直肌
                <a-select
                    v-model="
                  info.examination.examination_eyeballsport.left.lower_rectus
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="下直肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.examination.examination_eyeballsport.left.normal==false">上斜肌
                <a-select
                    v-model="
                  info.examination.examination_eyeballsport.left.upper_oblique
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="上斜肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.examination.examination_eyeballsport.left.normal==false">下斜肌
                <a-select
                    v-model="
                  info.examination.examination_eyeballsport.left.lower_oblique
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="下斜肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
            </a-descriptions-item>
          </a-descriptions>
        </a-descriptions-item>
      </a-descriptions>
      <a-descriptions title="诊断" :column="1" bordered class="descriptions">
        <a-descriptions-item label="斜视类型">
          <a-checkbox-group
            v-model="diagnosis_strabismus_type"
            name="strabismusType"
          />
<!--          :options="strabismusOptions"-->
          <p>隐斜视</p>
          <a-select
              v-model="info.diagnosis.latent_strabismus"
              style="margin-top: 5px;"
              placeholder="隐斜视"
          >
            <a-select-option :value="true">是</a-select-option>
            <a-select-option :value="false">否</a-select-option>
          </a-select>
          <p>内斜视</p>
          <a-select
            v-model="info.diagnosis.Internal_strabismus"
            style="margin-top: 5px; width: 100%;"
            placeholder="内斜视"
          >
            <a-select-option value="无">无</a-select-option>
            <a-select-option
              v-for="item of strabismusTypeOptions1"
              :key="item.value"
              :value="item.value"
              >{{ item.label }}</a-select-option
            >
          </a-select>
          <p>外斜视</p>
          <a-select
            v-model="info.diagnosis.Exotropia"
            style="margin-top: 5px; width: 100%;"
            placeholder="外斜视"
          >
            <a-select-option value="无">无</a-select-option>
            <a-select-option
              v-for="item of strabismusTypeOptions2"
              :key="item.value"
              :value="item.value"
              >{{ item.label }}</a-select-option
            >
          </a-select>
          <p>A⁃V型斜视</p>
          <a-select
            v-model="info.diagnosis.A_V"
            style="margin-top: 5px; width: 100%;"
            placeholder="A⁃V型斜视"
          >
            <a-select-option value="无">无</a-select-option>
            <a-select-option
              v-for="item of strabismusTypeOptions3"
              :key="item.value"
              :value="item.value"
              >{{ item.label }}</a-select-option
            >
          </a-select>
          <p>垂直旋转性斜视</p>
          <a-select
            v-model="info.diagnosis.V"
            style="margin-top: 5px; width: 100%;"
            placeholder="垂直旋转性斜视"
          >
            <a-select-option value="无">无</a-select-option>
            <a-select-option
              v-for="item of strabismusTypeOptions4"
              :key="item.value"
              :value="item.value"
              >{{ item.label }}</a-select-option
            >
          </a-select>
          <p>特殊类型斜视</p>
          <a-select
            v-model="info.diagnosis.S"
            style="margin-top: 5px; width: 100%;"
            placeholder="特殊类型斜视"
          >
            <a-select-option value="无">无</a-select-option>
            <a-select-option
              v-for="item of strabismusTypeOptions5"
              :key="item.value"
              :value="item.value"
              >{{ item.label }}</a-select-option
            >
          </a-select>
          <p>中枢性麻痹性斜视</p>
          <a-select
            v-model="info.diagnosis.PS"
            style="margin-top: 5px; width: 100%;"
            placeholder="中枢性麻痹性斜视"
          >
            <a-select-option value="无">无</a-select-option>
            <a-select-option
              v-for="item of strabismusTypeOptions6"
              :key="item.value"
              :value="item.value"
              >{{ item.label }}</a-select-option
            >
          </a-select>
          <p>眼球震颤</p>
          <a-select
            v-model="info.diagnosis.N"
            style="margin-top: 5px;"
            placeholder="眼球震颤"
          >
            <a-select-option :value="true">是</a-select-option>
            <a-select-option :value="false">否</a-select-option>
          </a-select>
          <p>其他</p>
          <a-select
              v-model="info.diagnosis.other"
              style="margin-top: 5px;"
              placeholder="其他"
          >
            <a-select-option :value="true">是</a-select-option>
            <a-select-option :value="false">否</a-select-option>
          </a-select>
        </a-descriptions-item>
      </a-descriptions>
      <a-descriptions
        title="手术设计"
        :column="1"
        bordered
        class="descriptions"
      >
        <a-descriptions-item label="右眼（手术）">
<!--          <a-checkbox-group name="surgeryType" v-model="info.surgery.surgery_yb">-->
<!--            <a-checkbox value="right">右眼</a-checkbox>-->
<!--            <a-checkbox value="left">左眼</a-checkbox>-->
<!--          </a-checkbox-group>-->
            <a-descriptions :column="1" bordered>

              <a-descriptions-item label="外直肌手术">
                <span>方式
                <a-select
                    v-model="info.surgery.right.external_rectus_way"
                    style="margin-top: 5px; width: 20%;"
                >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                    v-for="item of surgery_way"
                    :key="item.value"
                    :value="item.value"
                >{{ item.label }}
                </a-select-option>
                </a-select>
                </span>
                <span>量值
                  <a-select
                      v-model="info.surgery.right.external_rectus_value"
                      style="margin-top: 5px; width: 20%;"
                  >
                    <a-select-option value="无">无</a-select-option>
                  <a-select-option
                      v-for="item in value" v-bind:key="item.id"
                  >{{ item }}
                  </a-select-option>
                  </a-select>
            </span>
              </a-descriptions-item>
              <a-descriptions-item label="内直肌手术">
                <span>方式
                <a-select
                    v-model="info.surgery.right.internal_rectus_way"
                    style="margin-top: 5px; width: 20%;"
                >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                    v-for="item of surgery_way"
                    :key="item.value"
                    :value="item.value"
                >{{ item.label }}
                </a-select-option>
                </a-select>
                </span>
                <span>量值
                  <a-select
                      v-model="info.surgery.right.internal_rectus_value"
                      style="margin-top: 5px; width: 20%;"
                  >
                    <a-select-option value="无">无</a-select-option>
                  <a-select-option
                      v-for="item in value" v-bind:key="item.id"
                  >{{ item }}
                  </a-select-option>
                  </a-select>
            </span>
              </a-descriptions-item>
              <a-descriptions-item label="上直肌手术">
                <span>方式
                <a-select
                    v-model="info.surgery.right.upper_rectus_way"
                    style="margin-top: 5px; width: 20%;"
                >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                    v-for="item of surgery_way"
                    :key="item.value"
                    :value="item.value"
                >{{ item.label }}
                </a-select-option>
                </a-select>
                </span>
                <span>量值
                  <a-select
                      v-model="info.surgery.right.upper_rectus_value"
                      style="margin-top: 5px; width: 20%;"
                  >
                    <a-select-option value="无">无</a-select-option>
                  <a-select-option
                      v-for="item in value" v-bind:key="item.id"
                  >{{ item }}
                  </a-select-option>
                  </a-select>
            </span>
              </a-descriptions-item>
              <a-descriptions-item label="下直肌手术">
                <span>方式
                <a-select
                    v-model="info.surgery.right.lower_rectus_way"
                    style="margin-top: 5px; width: 20%;"
                >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                    v-for="item of surgery_way"
                    :key="item.value"
                    :value="item.value"
                >{{ item.label }}
                </a-select-option>
                </a-select>
                </span>
                <span>量值
                  <a-select
                      v-model="info.surgery.right.lower_rectus_value"
                      style="margin-top: 5px; width: 20%;"
                  >
                    <a-select-option value="无">无</a-select-option>
                  <a-select-option
                      v-for="item in value" v-bind:key="item.id"
                  >{{ item }}
                  </a-select-option>
                  </a-select>
            </span>
              </a-descriptions-item>
              <a-descriptions-item label="上斜肌手术">
                <span>方式
                <a-select
                    v-model="info.surgery.right.upper_oblique_way"
                    style="margin-top: 5px; width: 20%;"
                >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                    v-for="item of surgery_way"
                    :key="item.value"
                    :value="item.value"
                >{{ item.label }}
                </a-select-option>
                </a-select>
                </span>
                <span>量值
                  <a-select
                      v-model="info.surgery.right.upper_oblique_value"
                      style="margin-top: 5px; width: 20%;"
                  >
                    <a-select-option value="无">无</a-select-option>
                  <a-select-option
                      v-for="item in value" v-bind:key="item.id"
                  >{{ item }}
                  </a-select-option>
                  </a-select>
            </span>
              </a-descriptions-item>
              <a-descriptions-item label="下斜肌手术">
                <span>方式
                <a-select
                    v-model="info.surgery.right.lower_oblique_way"
                    style="margin-top: 5px; width: 20%;"
                >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                    v-for="item of surgery_way"
                    :key="item.value"
                    :value="item.value"
                >{{ item.label }}
                </a-select-option>
                </a-select>
                </span>
                <span>量值
                  <a-select
                      v-model="info.surgery.right.lower_oblique_value"
                      style="margin-top: 5px; width: 20%;"
                  >
                    <a-select-option value="无">无</a-select-option>
                  <a-select-option
                      v-for="item in value" v-bind:key="item.id"
                  >{{ item }}
                  </a-select-option>
                  </a-select>
            </span>
              </a-descriptions-item>

            </a-descriptions>
        </a-descriptions-item>
        <a-descriptions-item label="左眼（手术）">
          <!--          <a-checkbox-group name="surgeryType" v-model="info.surgery.surgery_yb">-->
          <!--            <a-checkbox value="right">右眼</a-checkbox>-->
          <!--            <a-checkbox value="left">左眼</a-checkbox>-->
          <!--          </a-checkbox-group>-->
          <a-descriptions :column="1" bordered>

            <a-descriptions-item label="外直肌手术">
                <span>方式
                <a-select
                    v-model="info.surgery.left.external_rectus_way"
                    style="margin-top: 5px; width: 20%;"
                >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                    v-for="item of surgery_way"
                    :key="item.value"
                    :value="item.value"
                >{{ item.label }}
                </a-select-option>
                </a-select>
                </span>
              <span>量值
                  <a-select
                      v-model="info.surgery.left.external_rectus_value"
                      style="margin-top: 5px; width: 20%;"
                  >
                    <a-select-option value="无">无</a-select-option>
                  <a-select-option
                      v-for="item in value" v-bind:key="item.id"
                  >{{ item }}
                  </a-select-option>
                  </a-select>
            </span>
            </a-descriptions-item>
            <a-descriptions-item label="内直肌手术">
                <span>方式
                <a-select
                    v-model="info.surgery.left.internal_rectus_way"
                    style="margin-top: 5px; width: 20%;"
                >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                    v-for="item of surgery_way"
                    :key="item.value"
                    :value="item.value"
                >{{ item.label }}
                </a-select-option>
                </a-select>
                </span>
              <span>量值
                  <a-select
                      v-model="info.surgery.left.internal_rectus_value"
                      style="margin-top: 5px; width: 20%;"
                  >
                    <a-select-option value="无">无</a-select-option>
                  <a-select-option
                      v-for="item in value" v-bind:key="item.id"
                  >{{ item }}
                  </a-select-option>
                  </a-select>
            </span>
            </a-descriptions-item>
            <a-descriptions-item label="上直肌手术">
                <span>方式
                <a-select
                    v-model="info.surgery.left.upper_rectus_way"
                    style="margin-top: 5px; width: 20%;"
                >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                    v-for="item of surgery_way"
                    :key="item.value"
                    :value="item.value"
                >{{ item.label }}
                </a-select-option>
                </a-select>
                </span>
              <span>量值
                  <a-select
                      v-model="info.surgery.left.upper_rectus_value"
                      style="margin-top: 5px; width: 20%;"
                  >
                    <a-select-option value="无">无</a-select-option>
                  <a-select-option
                      v-for="item in value" v-bind:key="item.id"
                  >{{ item }}
                  </a-select-option>
                  </a-select>
            </span>
            </a-descriptions-item>
            <a-descriptions-item label="下直肌手术">
                <span>方式
                <a-select
                    v-model="info.surgery.left.lower_rectus_way"
                    style="margin-top: 5px; width: 20%;"
                >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                    v-for="item of surgery_way"
                    :key="item.value"
                    :value="item.value"
                >{{ item.label }}
                </a-select-option>
                </a-select>
                </span>
              <span>量值
                  <a-select
                      v-model="info.surgery.left.lower_rectus_value"
                      style="margin-top: 5px; width: 20%;"
                  >
                    <a-select-option value="无">无</a-select-option>
                  <a-select-option
                      v-for="item in value" v-bind:key="item.id"
                  >{{ item }}
                  </a-select-option>
                  </a-select>
            </span>
            </a-descriptions-item>
            <a-descriptions-item label="上斜肌手术">
                <span>方式
                <a-select
                    v-model="info.surgery.left.upper_oblique_way"
                    style="margin-top: 5px; width: 20%;"
                >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                    v-for="item of surgery_way"
                    :key="item.value"
                    :value="item.value"
                >{{ item.label }}
                </a-select-option>
                </a-select>
                </span>
              <span>量值
                  <a-select
                      v-model="info.surgery.left.upper_oblique_value"
                      style="margin-top: 5px; width: 20%;"
                  >
                    <a-select-option value="无">无</a-select-option>
                  <a-select-option
                      v-for="item in value" v-bind:key="item.id"
                  >{{ item }}
                  </a-select-option>
                  </a-select>
            </span>
            </a-descriptions-item>
            <a-descriptions-item label="下斜肌手术">
                <span>方式
                <a-select
                    v-model="info.surgery.left.lower_oblique_way"
                    style="margin-top: 5px; width: 20%;"
                >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                    v-for="item of surgery_way"
                    :key="item.value"
                    :value="item.value"
                >{{ item.label }}
                </a-select-option>
                </a-select>
                </span>
              <span>量值
                  <a-select
                      v-model="info.surgery.left.lower_oblique_value"
                      style="margin-top: 5px; width: 20%;"
                  >
                    <a-select-option value="无">无</a-select-option>
                  <a-select-option
                      v-for="item in value" v-bind:key="item.id"
                  >{{ item }}
                  </a-select-option>
                  </a-select>
            </span>
            </a-descriptions-item>

          </a-descriptions>
        </a-descriptions-item>
<!--          <a-descriptions-item label="手术值" v-if="info.surgery.external_rectus_way!='无'">-->
<!--            <a-input v-model="info.surgery.external_rectus_value" placeholder="请输入"></a-input>-->
<!--          </a-descriptions-item>-->
<!--          <a-descriptions-item label="备注" v-if="info.surgery.muscle===true">-->
<!--            <a-input v-model="info.surgery.beizhu" placeholder="请输入"></a-input>-->
<!--          </a-descriptions-item>-->
<!--        <a-descriptions-item label="左眼肌肉（手术）">-->
<!--          <a-radio-group name="surgeryMuscleType1" v-model="info.surgery.muscle1">-->
<!--            <a-radio :value="true">使用</a-radio>-->
<!--            <a-radio :value="false">不使用</a-radio>-->
<!--          </a-radio-group>-->
<!--        </a-descriptions-item>2-->
<!--        <a-descriptions-item label="手术方式" v-if="info.surgery.muscle1===true">-->
<!--          <a-input v-model="info.surgery.way1" placeholder="请输入"></a-input>-->
<!--        </a-descriptions-item>-->
<!--        <a-descriptions-item label="手术值" v-if="info.surgery.muscle1===true">-->
<!--          <a-input v-model="info.surgery.value1" placeholder="请输入"></a-input>-->
<!--        </a-descriptions-item>-->
<!--        <a-descriptions-item label="备注" v-if="info.surgery.muscle1===true">-->
<!--          <a-input v-model="info.surgery.beizhu1" placeholder="请输入"></a-input>-->
<!--        </a-descriptions-item>-->
<!--      </a-descriptions>-->
      </a-descriptions>
      <a-descriptions
        title="出院时情况"
        :column="1"
        bordered
        class="descriptions"
      >
        <a-descriptions-item label="立体视">
          <a-descriptions :column="1" bordered>
            <a-descriptions-item label="近方随机点立体视">
              <a-select
                v-model="
                  info.leave_history.leave_hospital_lts.examination_lts_j
                "
                style="width: 100%;"
                placeholder="请选择"
              >
                <a-select-option value="No">无</a-select-option>
                <a-select-option value="20">20</a-select-option>
                <a-select-option value="40">40</a-select-option>
                <a-select-option value="60">60</a-select-option>
                <a-select-option value="100">100</a-select-option>
                <a-select-option value="200">200</a-select-option>
                <a-select-option value="400">400</a-select-option>
                <a-select-option value="800">800</a-select-option>
                <a-select-option value="1000">1000</a-select-option>
              </a-select>
            </a-descriptions-item>
            <a-descriptions-item label="远方随机点立体视">
              <a-select
                v-model="
                  info.leave_history.leave_hospital_lts.examination_lts_y
                "
                style="width: 100%;"
                placeholder="请选择"
              >
                <a-select-option value="No">无</a-select-option>
                <a-select-option value="20">20</a-select-option>
                <a-select-option value="40">40</a-select-option>
                <a-select-option value="60">60</a-select-option>
                <a-select-option value="100">100</a-select-option>
                <a-select-option value="200">200</a-select-option>
                <a-select-option value="400">400</a-select-option>
                <a-select-option value="800">800</a-select-option>
                <a-select-option value="1000">1000</a-select-option>
              </a-select>
            </a-descriptions-item>
          </a-descriptions>
        </a-descriptions-item>
        <a-descriptions-item label="角膜映光">
          <a-radio-group
            v-model="leave_hospital_cornea_type"
            placeholder="请选择"
          >
            <a-radio :value="true" @change="leave_jmygrnull1">水平值</a-radio>
            <a-radio :value="false" @change="leave_jmygrnull2">垂直值</a-radio>
          </a-radio-group>
          <a-select
            v-if="leave_hospital_cornea_type"
            v-model="
              info.leave_history.leave_hospital_cornea.examination_cornea_sp
            "
            style="width: 100px; margin-left: 10px;"
            placeholder="请选择"
          >
            <a-select-option value="无">无</a-select-option>
            <a-select-option value=">45">>45</a-select-option>
            <a-select-option
              v-for="item of 19"
              :key="item"
              :value="`${item * 5 - 50}`"
            >
              {{ item * 5 - 50 }}
            </a-select-option>
            <a-select-option value="<-45">&lt;-45</a-select-option>
          </a-select>
          <template v-else-if="!leave_hospital_cornea_type">
            <a-select
              v-model="
                // eslint-disable-next-line prettier/prettier
                info.leave_history.leave_hospital_cornea.examination_cornea_cz
              "
              style="margin-left: 10px;"
              placeholder="请选择"
            >
              <a-select-option value="无">无</a-select-option>
              <a-select-option value="R_L">R/L</a-select-option>
              <a-select-option value="L_R">L/R</a-select-option>
              <a-select-option value="NO">NO</a-select-option>
            </a-select>
            <a-select
              v-if="
                // eslint-disable-next-line prettier/prettier
                info.leave_history.leave_hospital_cornea.examination_cornea_cz !== 'NO'
              "
              v-model="
                info.leave_history.leave_hospital_cornea.examination_cornea_cz_z
              "
              style="width: 100px; margin-left: 10px;"
              placeholder="请选择"
            >
              <a-select-option value="无">无</a-select-option>
              <a-select-option value=">45">>45</a-select-option>
              <a-select-option
                v-for="item of 19"
                :key="item"
                :value="`${item * 5 - 50}`"
              >
                {{ item * 5 - 50 }}
              </a-select-option>
              <a-select-option value="<-45">&lt;-45</a-select-option>
            </a-select>
          </template>
        </a-descriptions-item>
        <a-descriptions-item label="三棱镜">
          <a-descriptions :column="1" bordered>
            <a-descriptions-item label="视近">
              <a-select
                v-model="
                  info.leave_history.leave_hospital_slj.leave_hospital_slj_near
                "
                style="width: 100%;"
                placeholder="请选择"
              >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                  v-for="item of 13"
                  :key="item"
                  :value="`${item * 5 - 35}`"
                >
                  {{ item * 5 - 35 }}
                </a-select-option>
              </a-select>
            </a-descriptions-item>
            <a-descriptions-item label="视远">
              <a-select
                v-model="
                  info.leave_history.leave_hospital_slj.leave_hospital_slj_far
                "
                style="width: 100%;"
                placeholder="请选择"
              >
                <a-select-option value="无">无</a-select-option>
                <a-select-option
                  v-for="item of 13"
                  :key="item"
                  :value="`${item * 5 - 35}`"
                >
                  {{ item * 5 - 35 }}
                </a-select-option>
              </a-select>
            </a-descriptions-item>
          </a-descriptions>
        </a-descriptions-item>
        <a-descriptions-item label="眼球运动">
          <a-descriptions :column="1" bordered>
            <a-descriptions-item label="眼球运动右眼">
              <a-checkbox-group
                  v-model="leave_hospital_eyeballsport_right"
                  name="movementRightEyeType"
              />
              <p>正常
                <a-select
                    v-model="
                  info.leave_history.leave_hospital_eyeballsport.right.normal
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="请选择"
                >
                  <a-select-option :value="true">是</a-select-option>
                  <a-select-option :value="false">否</a-select-option>
                </a-select>
              </p>
              <p v-if="info.leave_history.leave_hospital_eyeballsport.right.normal==false">外直肌
                <a-select
                    v-model="
                    info.leave_history.leave_hospital_eyeballsport.right.external_rectus
                  "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="请选择"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.leave_history.leave_hospital_eyeballsport.right.normal==false">内直肌
                <a-select

                    v-model="
                  info.leave_history.leave_hospital_eyeballsport.right.internal_rectus
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="内直肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.leave_history.leave_hospital_eyeballsport.right.normal==false">上直肌
                <a-select
                    v-model="
                  info.leave_history.leave_hospital_eyeballsport.right.upper_rectus
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="上直肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.leave_history.leave_hospital_eyeballsport.right.normal==false">下直肌
                <a-select
                    v-model="
                  info.leave_history.leave_hospital_eyeballsport.right.lower_rectus
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="下直肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.leave_history.leave_hospital_eyeballsport.right.normal==false">上斜肌
                <a-select
                    v-model="
                  info.leave_history.leave_hospital_eyeballsport.right.upper_oblique
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="上斜肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.leave_history.leave_hospital_eyeballsport.right.normal==false">下斜肌
                <a-select
                    v-model="
                  info.leave_history.leave_hospital_eyeballsport.right.lower_oblique
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="下斜肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>

            </a-descriptions-item>
            <a-descriptions-item label="眼球运动左眼">
              <a-checkbox-group
                  v-model="leave_hospital_eyeballsport_left"
                  name="movementLeftEyeType"
              />
              <p>正常
                <a-select
                    v-model="info.leave_history.leave_hospital_eyeballsport.left.normal"
                    style="width: 100px;margin-right: 10px;"
                    placeholder="请选择"
                >
                  <a-select-option :value="true">是</a-select-option>
                  <a-select-option :value="false">否</a-select-option>
                </a-select>
              </p>
              <p v-if="info.leave_history.leave_hospital_eyeballsport.left.normal==false">外直肌
                <a-select
                    v-model="
                    info.leave_history.leave_hospital_eyeballsport.left.external_rectus
                  "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="请选择"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.leave_history.leave_hospital_eyeballsport.left.normal==false">内直肌
                <a-select
                    v-model="
                  info.leave_history.leave_hospital_eyeballsport.left.internal_rectus
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="内直肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.leave_history.leave_hospital_eyeballsport.left.normal==false">上直肌
                <a-select
                    v-model="
                  info.leave_history.leave_hospital_eyeballsport.left.upper_rectus
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="上直肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.leave_history.leave_hospital_eyeballsport.left.normal==false">下直肌
                <a-select
                    v-model="
                  info.leave_history.leave_hospital_eyeballsport.left.lower_rectus
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="下直肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.leave_history.leave_hospital_eyeballsport.left.normal==false">上斜肌
                <a-select
                    v-model="
                  info.leave_history.leave_hospital_eyeballsport.left.upper_oblique
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="上斜肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
              <p v-if="info.leave_history.leave_hospital_eyeballsport.left.normal==false">下斜肌
                <a-select
                    v-model="
                  info.leave_history.leave_hospital_eyeballsport.left.lower_oblique
                "
                    style="width: 100px;margin-right: 10px;"
                    placeholder="下斜肌"
                >
                  <a-select-option :value="0">0</a-select-option>
                  <a-select-option v-for="item in list" v-bind:key="item.id">
                    {{ item }}
                  </a-select-option>
                </a-select>
              </p>
            </a-descriptions-item>
          </a-descriptions>
        </a-descriptions-item>
      </a-descriptions>
      <a-descriptions
        title="随访时间"
        :column="1"
        bordered
        class="descriptions"
      >
        <a-descriptions-item label="随访时间">
          <a-date-picker
            v-model="info.base_info.suifang"
            style="width: 100%;"
            placeholder="请选择"
          />
        </a-descriptions-item>
      </a-descriptions>
      <a-descriptions title="备注" :column="1" bordered class="descriptions">
        <a-descriptions-item label="备注">
          <a-textarea
            v-model="info.base_info.beizhu"
            placeholder="请输入..."
            :auto-size="{ minRows: 3, maxRows: 5 }"
          />
        </a-descriptions-item>
      </a-descriptions>
      <div style="text-align: center;">
        <a-button type="primary" :loading="loading" @click="submit"
          >提交</a-button
        >
        <a-button  @click="history.back(-1)"
        >返回</a-button
        >
      </div>
    </template>
  </div>
</template>
<script>
import { mapState } from "vuex";
import _ from "underscore";

export default {
  name: "Detail",
  data() {

    return {
      list:[-4,-3,-2,-1,1,2,3,4],
      value:[0,0.5,1.0,1.5,2.0,2.5,3.0,3.5,4.0,4.5,5.0,5.5,6.0,6.5,7.0,7.5,8.0,8.5,9.0,9.5,10.0],
      loading: false,
      viewLoading: false,
      movementRightEyeOptions: [
        { label: "正常（右）", value: "normal" },
        { label: "外直肌", value: "external_rectus"},
        { label: "内直肌", value: "internal_rectus"},
        { label: "上直肌", value: "upper_rectus" },
        { label: "下直肌", value: "lower_rectus" },
        { label: "上斜肌", value: "upper_oblique" },
        { label: "下斜肌", value: "lower_oblique" }
      ],
      movementLeftEyeOptions: [
        { label: "正常（左）", value: "normal" },
        { label: "外直肌", value: "external_rectus" },
        { label: "内直肌", value: "internal_rectus" },
        { label: "上直肌", value: "upper_rectus" },
        { label: "下直肌", value: "lower_rectus" },
        { label: "上斜肌", value: "upper_oblique" },
        { label: "下斜肌", value: "lower_oblique" }
      ],
      strabismusOptions: [
        { label: "隐斜视", value: "latent_strabismus" },
        { label: "内斜视", value: "Internal_strabismus" },
        { label: "外斜视", value: "Exotropia" },
        { label: "A⁃V型斜视", value: "A_V" },
        { label: "垂直旋转性斜视", value: "V" },
        { label: "特殊类型斜视", value: "S" },
        { label: "中枢性麻痹性斜视", value: "PS" },
        { label: "眼球震颤", value: "N" },
        { label: "其他", value: "other" }
      ],
      strabismusTypeOptions1: [
        { label: "先天性(婴儿型)内斜视", value: "IE" },
        { label: "共同性内斜视", value: "CE" },
        { label: "继发性内斜视", value: "SE" },
        { label: "非共同性内斜视", value: "NE" },
        { label: "伴有眼球震颤的内斜视", value: "EN" }
      ],
      strabismusTypeOptions2: [
        { label: "先天性外斜视", value: "IF" },
        { label: "共同性外斜视-恒定性外斜视", value: "CF" },
        { label: "共同性外斜视-间歇式外斜视", value: "BF" },
        { label: "继发性外斜视", value: "SF" },
        { label: "非共同性外斜视-麻痹性外斜视", value: "NF" },
        { label: "非共同性外斜视-限制性外斜视", value: "MF" }
      ],
      strabismusTypeOptions3: [
        { label: "V型外斜视", value: "IE" },
        { label: "V型内斜视", value: "CE" },
        { label: "A型外斜视", value: "SE" },
        { label: "A型内斜视", value: "NE" },
      ],
      strabismusTypeOptions4: [
        { label: "上斜肌麻痹", value: "IE" },
        { label: "外旋转性斜视", value: "CE" },
        { label: "下斜肌功能亢进", value: "SE" },
        { label: "上斜肌功能亢进", value: "NE" },
        { label: "下斜肌麻痹", value: "SE" },
        { label: "单眼上转不足", value: "NE" },
        { label: "限制性垂直性斜视", value: "SE" },
      ],
      strabismusTypeOptions5: [
        { label: "分离性斜视", value: "IE" },
        { label: "间歇性外斜视合并调节性内斜视", value: "CE" },
        { label: "先天性眼外肌纤维化", value: "SE" },
        { label: "Duane眼球后退综合征", value: "NE" },
        { label: "Moebius综合征", value: "SE" },
        { label: "Brown综合征", value: "NE" },
        { label: "慢性进行性眼外肌麻痹", value: "SE" },
        { label: "重症肌无力", value: "NE" },
        { label: "眼眶爆裂性骨折", value: "SE" },
      ],
      strabismusTypeOptions6: [
        { label: "核性", value: "IE" },
        { label: "核间性", value: "CE" },
        { label: "核上性", value: "SE" },
      ],
      surgery_way:[
        {label:"后退",value:"way1"},
        {label:"缩短",value:"way2"},
        {label:"复位",value:"way3"},
        {label:"离断",value:"way4"},
        {label:"前徙",value:"way5"},
        {label:"转位",value:"way6"},
        {label:"延长",value:"way7"}
      ],
      info: null,
      examination_tsj_tss_none: true,
      examination_cornea_left_type: true,
      examination_cornea_right_type: true,
      examination_eyeballsport_left: [],
      examination_eyeballsport_right: [],
      leave_hospital_eyeballsport_left: [],
      leave_hospital_eyeballsport_right: [],
      surgery_left:[],
      surgery_right:[],
      diagnosis_strabismus_type: [],
      leave_hospital_cornea_type: true
    };
  },
  computed: {
    ...mapState({
      user: state => state.user
    })
  },
  created() {
    this.init();
    if (this.$route.query.id) {
      this.getDetail();
    }
  },
  methods: {
    init() {
      this.info = {
        base_info: {
          data_type: "门诊患者",
          user_name: "",
          sex: "男",
          age: "",
          id_number: "",
          phone_number: "",
          order_number: "",
          suifang: "",
          beizhu: ""
        },
        medical_history: {
          surgery_history: true,
          glasses_history: "",
          amblyopia_history: true,
          home_history: true,
          born_history: true,
          surgery_history_edit: "",
          now_age: "",
          now_wt: true,
          now_fs: true
        },
        examination: {
          examination_nv: {
            left: "",
            right: ""
          },
          examination_corrected_visual: {
            right: "",
            left: ""
          },
          examination_co: {
            right: {
              ds: 0,
              dc: 0,
              a: 0
            },
            left: {
              ds: 0,
              dc: 0,
              a: 0
            }
          },
          examination_ro: {
            right: {
              ds: 0,
              dc: 0,
              a: 0
            },
            left: {
              ds: 0,
              dc: 0,
              a: 0
            }
          },

          examination_tsj: {
            examination_tsj_tss: true,
            examination_tsj_tss_sp: "",
            examination_tsj_tss_cz: "NO",
            examination_tsj_tss_cs_z: ""
          },
          examination_lts: {
            examination_lts_j: "No",
            examination_lts_y: "No"
          },
          examination_cornea: {
            left: {
              examination_cornea_sp: "",
              examination_cornea_cz: "No",
              examination_cornea_cz_z: ""
            },
            right: {
              examination_cornea_sp: "",
              examination_cornea_cz: "No",
              examination_cornea_cz_z: ""
            }
          },
          examination_slj: {
            examination_slj_zj_near: "",
            examination_slj_zj_far: "",
            examination_slj_dy_near: "",
            examination_slj_dy_far: "",
            examination_slj_cz: "R_L",
            examination_slj_cz_z: "10",
            k_method: "10"
          },
          examination_eyeballsport: {
            left: {
              normal:false,
              external_rectus: "",
              internal_rectus: "",
              upper_rectus: "",
              lower_rectus: "",
              upper_oblique: "",
              lower_oblique: ""
            },

            right: {
              normal: false,
              external_rectus: "",
              internal_rectus: "",
              upper_rectus: "",
              lower_rectus: "",
              upper_oblique: "",
              lower_oblique: ""
            }
          },
          // examination_eyeballsport_left:function(one){
          //   one.normal = !one.normal;
          // },
          // examination_eyeballsport_right:function(one){
          //   one.normal = !one.normal;
          // },
          examination_control: {
            examination_Control: ""
          }
        },
        diagnosis: {
          latent_strabismus: false,
          Internal_strabismus: "",
          Exotropia: "",
          A_V: "",
          V: "",
          S: "",
          PS: "",
          N: false,
          other: false
        },
        // surgery1: {
        //   muscle1:true,
        //   way: "",
        //   value: "",
        //   beizhu: ""
        // },
        surgery: {
            //surgery_yb: "right",
          left:{
            external_rectus_way: "",
            external_rectus_value: "",
            internal_rectus_way: "",
            internal_rectus_value: "",
            upper_rectus_way: "",
            upper_rectus_value: "",
            lower_rectus_way: "",
            lower_rectus_value: "",
            upper_oblique_way: "",
            upper_oblique_value: "",
            lower_oblique_way: "",
            lower_oblique_value:"",
          },
          right:{
            external_rectus_way: "",
            external_rectus_value: "",
            internal_rectus_way: "",
            internal_rectus_value: "",
            upper_rectus_way: "",
            upper_rectus_value: "",
            lower_rectus_way: "",
            lower_rectus_value: "",
            upper_oblique_way: "",
            upper_oblique_value: "",
            lower_oblique_way: "",
            lower_oblique_value:"",
          },


              // way: "",
              // value: "",
          beizhu: ""
              // muscle1:true,
        },

        leave_history: {
          leave_hospital_lts: {
            examination_lts_j: "",
            examination_lts_y: ""
          },
          leave_hospital_cornea: {
            examination_cornea_sp: "",
            examination_cornea_cz: "No",
            examination_cornea_cz_z: ""
          },
          leave_hospital_slj: {
            leave_hospital_slj_near: "",
            leave_hospital_slj_far: ""
          },
          leave_hospital_eyeballsport: {
            left: {
              normal: false,
              external_rectus: "",
              internal_rectus: "",
              upper_rectus: "",
              lower_rectus: "",
              upper_oblique: "",
              lower_oblique: ""
            },
            right: {
              normal: false,
                                                                                                              external_rectus: "",
                                                                                                              internal_rectus: "",
                                                                                                              upper_rectus: "",
                                                                                                              lower_rectus: "",
                                                                                                              upper_oblique: "",
                                                                                                              lower_oblique: ""
            }
          }
        }
      };
    },
    checkAllGroupChange (data) {
      console.log(data); //无返回，不报错
      for(let item of data){
           alert(item);
          //examination_eyeballsport.right.external_rectus="";
       }

      //console.log("aaaaaaaaaaaaaaaa");
      //alert(data);
    },
    inputnull1(){
      this.info.examination.examination_tsj.examination_tsj_tss_cs_z="";
    },
    inputnull2(){
      this.info.examination.examination_tsj.examination_tsj_tss_sp=""
    },
    jmyglnull1(){
      this.info.examination.examination_cornea.left.examination_cornea_cz_z=""
    },
    jmyglnull2(){
      this.info.examination.examination_cornea.left.examination_cornea_sp=""
    },
    jmygrnull1(){
      this.info.examination.examination_cornea.right.examination_cornea_cz_z=""
    },
    jmygrnull2(){
      this.info.examination.examination_cornea.right.examination_cornea_sp=""
    },
    leave_jmygrnull1(){
      this.info.leave_history.leave_hospital_cornea.examination_cornea_cz_z=""
    },
    leave_jmygrnull2(){
      this.info.leave_history.leave_hospital_cornea.examination_cornea_sp=""
    },
    getDetail() {
      let param = {
        id: this.$route.query.id
      };
      this.viewLoading = true;
      this.$api("getCaseDetail", param, { slient: true, allowNoneZero: true })
        .then(response => {
          if (response) {
            if (response.return_code !== 0) {
              this.$message.error(response.return_msg);
            } else {
              this.info = response.case_data;
              if (
                 this.info.examination.examination_tsj.examination_tsj_tss_sp
              ) {
               //this.info.examination.examination_tsj.examination_tsj_cs_z="";
               this.examination_tsj_tss_none=true;
              }
              else
              {
                //this.info.examination.examination_tsj.examination_tsj_tss_sp="";
                this.examination_tsj_tss_none=false;
              }
              if (
                // eslint-disable-next-line prettier/prettier
                this.info.examination.examination_cornea.left.examination_cornea_sp
              ) {
                this.examination_cornea_left_type =true;
              }
              else{
                this.examination_cornea_left_type =false;
              }
              if (
                // eslint-disable-next-line prettier/prettier
                this.info.examination.examination_cornea.right.examination_cornea_sp
              ) {
                this.examination_cornea_right_type = true;
              }
              else{
                this.examination_cornea_right_type =false;
              }
              if(this.info.leave_history.leave_hospital_cornea.examination_cornea_sp)
              {
                this.leave_hospital_cornea_type=true;
              }
              else{
                this.leave_hospital_cornea_type=false;
              }
              this.examination_eyeballsport_left = [];
              for  (let item of _.keys(
                this.info.examination.examination_eyeballsport.left))
             {
                if (this.info.examination.examination_eyeballsport.left[item]) {
                  this.examination_eyeballsport_left.push(item);
                }
              }
              this.examination_eyeballsport_right = [];
              for (let item of _.keys(
                this.info.examination.examination_eyeballsport.right
              )) {
                if (
                  this.info.examination.examination_eyeballsport.right[item]
                ) {
                  this.examination_eyeballsport_right.push(item);
                }
              }
              this.leave_hospital_eyeballsport_left = [];
              for (let item of _.keys(
                this.info.leave_history.leave_hospital_eyeballsport.left
              )) {
                if (
                  this.info.leave_history.leave_hospital_eyeballsport.left[item]
                ) {
                  this.leave_hospital_eyeballsport_left.push(item);
                }
              }
              this.leave_hospital_eyeballsport_right = [];
              for (let item of _.keys(
                this.info.leave_history.leave_hospital_eyeballsport.right
              )) {
                if (
                  this.info.leave_history.leave_hospital_eyeballsport.right[
                    item
                  ]
                ) {
                  this.leave_hospital_eyeballsport_right.push(item);
                }
              }
              this.diagnosis_strabismus_type = [];
              for (let item of _.keys(this.info.diagnosis)) {
                if (this.info.diagnosis[item]) {
                  this.diagnosis_strabismus_type.push(item);
                }
              }
              this.surgery_left = [];
              for (let item of _.keys(
                  this.info.surgery.left
              )) {
                if (
                    this.info.surgery.left[item]
                ) {
                  this.surgery_left.push(item);
                }
              }
              this.surgery_right = [];
              for (let item of _.keys(
                  this.info.surgery.right
              )) {
                if (
                    this.info.surgery.right[item]
                ) {
                  this.surgery_right.push(item);
                }
              }
            }
          } else {
            this.$message.error("请求错误，请重试！");
          }
          return Promise.resolve();
        })
        .then(() => {
          this.viewLoading = false;
        });
    },
    submit() {
      let param = this.info;
      let url = "submitCaseContent";
      if (this.$route.query.id) {
        param = _.extend(this.info, { id: this.$route.query.id });
        url = "updateCaseContent";
      }
      this.loading = true;
      this.$api(url, param, {
        slient: true,
        allowNoneZero: true,
        json: true
      })
        .then(response => {
          if (response) {
            if (response.return_code !== 0) {
              this.$message.error(response.return_msg);
            } else {
              this.$message.success("提交成功！");
            }
          } else {
            this.$message.error("请求错误，请重试！");
          }
          return Promise.resolve();
        })
        .then(() => {
          this.loading = false;
        });
    }
  }
};
</script>
<style lang="stylus" scoped>
.detail >>> .ant-descriptions-item-label {
  width: 160px;
  color #2f54eb;
  font-weight bold;
}

.detail {
  .descriptions {
    margin-bottom: 20px;
  }

  .titles {
    border-bottom: 1px solid rgb(235, 237, 240);
    margin-bottom: 30px;
  }
}
</style>
