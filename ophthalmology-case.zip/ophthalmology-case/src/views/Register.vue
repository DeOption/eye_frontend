<template>
  <div class="register" style="min-height: 650px;">
    <a-card hoverable class="content">
      <div class="title">注册</div>
      <span>
        <div class="row">
          <div class="label">用户名称:</div>
          <a-input
            v-model="userName"
            style="width: 355px;"
            size="large"
            placeholder="请输入用户名称"
            :disabled="loading"
          >
            <a-icon slot="prefix" type="user" />
          </a-input>
        </div>
        <div class="row">
          <div class="label">用户密码:</div>
          <a-input
            v-model="userPassword"
            style="width: 355px;"
            size="large"
            type="password"
            placeholder="请输入用户密码"
            :disabled="loading"
          >
            <a-icon slot="prefix" type="lock" />
          </a-input>
        </div>
        <div class="row">
          <div class="label">确认密码:</div>
          <a-input
            v-model="reUserPassword"
            style="width: 355px;"
            size="large"
            type="password"
            placeholder="请再次输入用户密码"
            :disabled="loading"
          >
            <a-icon slot="prefix" type="lock" />
          </a-input>
        </div>
        <div class="row">
          <div class="label">手机号码:</div>
          <a-input
            v-model="userMobile"
            style="width: 355px;"
            size="large"
            placeholder="请输入手机号码"
            :disabled="loading"
          >
            <a-icon slot="prefix" type="phone" />
          </a-input>
        </div>
        <div class="row">
          <div class="label">电子邮箱:</div>
          <a-input
            v-model="userEmail"
            style="width: 355px;"
            size="large"
            placeholder="请输入电子邮箱"
            :disabled="loading"
          >
            <a-icon slot="prefix" type="mail" />
          </a-input>
        </div>
      </span>
      <span class="footer">
        <a-button
          style="margin-top: 10px; margin-bottom: 10px; width: 100%;"
          size="large"
          type="primary"
          :loading="loading"
          @click="register"
        >
          提 交
        </a-button>
        <router-link :to="{ name: 'Login' }">
          <a-button style="margin-bottom: 10px; float: left;" type="link">
            已有账户？立即登录
          </a-button>
        </router-link>
        <div class="copyright">
          Copyright @2020-{{ new Date().getFullYear() }} 价值眼
        </div>
      </span>
    </a-card>
  </div>
</template>
<script>
export default {
  name: "Register",
  data() {
    return {
      loading: false,
      userName: "",
      userPassword: "",
      reUserPassword: "",
      userMobile: "",
      userEmail: ""
    };
  },
  methods: {
    checkUserName() {
      let userNameError = "";
      if (this.userName === "") {
        userNameError = "用户名称不能为空！";
      }
      return { userNameError };
    },
    checkUserPassword() {
      let userPasswordError = "";
      if (this.userPassword === "") {
        userPasswordError = "用户密码不能为空！";
      } else if (
        this.userPassword.length < 6 ||
        this.userPassword.length > 18
      ) {
        userPasswordError = "用户密码长度需要大于6位小于18位！";
      }
      return { userPasswordError };
    },
    checkReUserPassword() {
      let userRePasswordError = "";
      if (this.reUserPassword === "") {
        userRePasswordError = "确认密码不能为空！";
      } else if (this.userPassword !== this.reUserPassword) {
        userRePasswordError = "两次输入密码不一致，请校验！";
      }
      return { userRePasswordError };
    },
    checkUserMobile() {
      let userMobileError = "";
      if (this.userMobile === "") {
        userMobileError = "手机号码不能为空！";
      } else if (!/^[1]([3-9])[0-9]{9}$/.test(this.userMobile)) {
        userMobileError = "请输入正确的手机号码！";
      }
      return { userMobileError };
    },
    checkUserEmail() {
      let userEmailError = "";
      if (this.userEmail === "") {
        userEmailError = "电子邮箱不能为空！";
      } else if (
        !/^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/.test(
          this.userEmail
        )
      ) {
        userEmailError = "请输入正确的电子邮箱！";
      }
      return { userEmailError };
    },
    register() {
      let { userNameError } = this.checkUserName();
      let { userPasswordError } = this.checkUserPassword();
      let { userRePasswordError } = this.checkReUserPassword();
      let { userMobileError } = this.checkUserMobile();
      let { userEmailError } = this.checkUserEmail();
      if (userNameError !== "") {
        this.$message.error(userNameError);
        return;
      } else if (userPasswordError !== "") {
        this.$message.error(userPasswordError);
        return;
      } else if (userRePasswordError !== "") {
        this.$message.error(userRePasswordError);
        return;
      } else if (userMobileError !== "") {
        this.$message.error(userMobileError);
        return;
      } else if (userEmailError !== "") {
        this.$message.error(userEmailError);
        return;
      }
      let param = {
        name: this.userName,
        password: this.userPassword,
        phone: this.userMobile,
        email: this.userEmail
      };
      this.loading = true;
      this.$api("userRegister", param, {
        slient: true,
        allowNoneZero: true,
        json: true
      })
        .then(response => {
          if (response) {
            if (response.return_code !== 0) {
              this.$message.error(response.return_msg);
            } else {
              this.$message.success("创建成功！");
              this.$router.push({ name: "Login" });
            }
          } else {
            this.$message.error("请求错误，请重试！");
          }
          return Promise.resolve();
        })
        .then(() => {
          this.loading = false;
        });
    }
  }
};
</script>
<style lang="stylus" scoped>
.register
  width 100%
  height 500px
  display flex
  justify-content center
  align-items center
  background-image url(https://gw.alipayobjects.com/zos/rmsportal/TVYTbAXWheQpRcWDaDMu.svg)
  background-repeat no-repeat
  background-position center 110px
  background-size 100%
  .row
    height 60px
    line-height 60px
    .label
      width 80px
      font-weight bold
      display inline-block
  .title
    width 100%
    margin-top 25px
    margin-bottom 35px
    color rgba(0, 0, 0, 0.85)
    font-weight 600
    font-size 33px
    font-family Avenir, helvetica neue, Arial, Helvetica, sans-serif
    text-align center
  .content
    width 500px
    height 600px
  .copyright
    margin-top 60px
    text-align center
    color rgba(0,0,0,.45)
    font-size 14px
</style>
