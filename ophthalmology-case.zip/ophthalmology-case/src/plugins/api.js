import _ from "underscore";
import axios from "../api/axios";
import apiConfig from "../api/api";
import commonUtils from "@/common/utils";

export default {
  install(Vue) {
    Vue.prototype.$api = function(apiName, data, options = {}) {
      let keys = Object.keys(apiConfig);
      if (keys.indexOf(apiName) === -1) {
        return Promise.reject({ message: `接口${apiName}不存在` });
      }
      let config = commonUtils.deepCopy(apiConfig[apiName]);
      config.routeName = this.$route.name;
      if (data && typeof data === "object" && !Array.isArray(data)) {
        let method = config.method ? config.method.toUpperCase() : "GET";
        if (["PUT", "POST", "PATCH"].indexOf(method) !== -1) {
          if (config.isProxyReq) {
            config.data.data.data = _.extend(
              {},
              config.data.data.data,
              data || {}
            );
            config.data.data = JSON.stringify(config.data.data);
          } else {
            config.data = _.extend({}, config.data || {}, data || {});
          }
        } else {
          if (config.isProxyReq) {
            config.params.data.data = _.extend(
              {},
              config.params.data.data,
              data || {}
            );
          } else {
            config.params = _.extend({}, config.params || {}, data || {});
          }
        }
      }
      if (options && typeof options === "object" && !Array.isArray(options)) {
        let keys = Object.keys(config);
        if (options.json) {
          if (!options.headers) {
            options.headers = {};
          }
          options.headers["content-type"] = "application/json";
        }
        config = _.extend({}, config, _.omit(options, ...keys));
      }
      return axios.request(config);
    };
  }
};
