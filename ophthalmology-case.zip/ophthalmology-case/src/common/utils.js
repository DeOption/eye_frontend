export default {
  deepCopy(source) {
    let target;
    if (!source) {
      target = source;
    } else if (Array.isArray(source)) {
      target = [];
      for (let item of source) {
        target.push(this.deepCopy(item));
      }
    } else if (typeof source === "object") {
      target = {};
      for (let key of Object.keys(source)) {
        target[key] = this.deepCopy(source[key]);
      }
    } else {
      target = source;
    }
    return target;
  },

  setCookie(name, value) {
    var exp = new Date();
    exp.setTime(exp.getTime() + 24 * 60 * 60 * 1000);
    document.cookie = `${name}=${escape(value)};expires=${exp.toGMTString()}`;
  }
};
