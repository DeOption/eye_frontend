<template>
  <div id="app">
<!--    页面返回不刷新-->
<!--    <keep-alive>-->
<!--      <router-view v-if="$route.meta.keepAlive"></router-view>-->
<!--    </keep-alive>-->
<!--    <router-view v-if="!$route.meta.keepAlive"></router-view>-->
    <a-layout
      class="warpper"
      :class="{ 'app-container-fullpage': isFullPageApp }"
    >
      <a-layout-header class="header">
        <div class="logo" />
        <router-link class="login-btn" :to="{ name: 'Login' }">
          <a-button type="primary" icon="login">
            {{ user.accessToken ? "切换账号" : "登录" }}
          </a-button>
        </router-link>
        <router-link class="register-btn" :to="{ name: 'Register' }">
<!--          <a-button type="primary" icon="plus-circle">注册</a-button>-->
        </router-link>
      </a-layout-header>
      <a-layout>
        <a-layout-sider class="sider" width="200" style="background: #fff">
          <a-menu
            mode="inline"
            :default-open-keys="['eye']"
            :default-selected-keys="selectedKeys"
            :style="{ height: '100%', borderRight: 0 }"
            @click="onMenuClick"
          >
            <a-sub-menu key="eye">
              <span slot="title" style="font-weight: bolder;font-size: large"> 价值眼 </span>
              <a-menu-item key="list" style="font-weight: bolder;"> 病例列表 </a-menu-item>
              <a-menu-item key="detail" style="font-weight: bolder;"> 病例详情 </a-menu-item>
            </a-sub-menu>
          </a-menu>
        </a-layout-sider>
        <a-layout style="padding: 0 24px 24px">
          <a-breadcrumb class="breadcrumb" style="margin: 16px 0">
            <a-breadcrumb-item>价值眼</a-breadcrumb-item>
            <a-breadcrumb-item>眼科病例</a-breadcrumb-item>
          </a-breadcrumb>
          <a-layout-content class="content">
            <router-view />
          </a-layout-content>
<!--          <a-layout-footer class="sider" style="text-align: center">-->
<!--            价值眼 ©2020-->
<!--          </a-layout-footer>-->
        </a-layout>
      </a-layout>
    </a-layout>
  </div>
</template>

<script>
import { mapState } from "vuex";

export default {
  data() {
    return {
      collapsed: false,
      selectedKeys: ["list"]
    };
  },
  computed: {
    ...mapState({
      user: state => state.user,
      isFullPageApp: state => state.isFullPageApp
    })
  },
  methods: {
    onMenuClick(item) {
      if (item.key === "list") {
        this.$router.push({ name: "List" });
      } else if (item.key === "detail") {
        this.$router.push({ name: "Detail" });
      }
    }
  }
};
</script>

<style lang="stylus">
#app,
.warpper
  height 100%
.app-container-fullpage
  .header,
  .sider,
  .breadcrumb
    display none
  .content
    margin 0
.warpper .logo{
  float: left;
  width: 120px;
  height: 31px;
  background: rgba(255, 255, 255, 0.2);
  margin: 16px 28px 16px 0;
}
.register-btn {
  float: right;
  margin-right: 10px;
}
.login-btn {
  float: right;
}
.content {
  background: #fff;
  padding: 24px;
  margin: 0;
  minHeight: 280px;
  overflow-x: hidden;
  overflow-y: auto;
}
</style>
