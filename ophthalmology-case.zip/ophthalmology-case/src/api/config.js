const CONFIG = {
  development: {
    // Mock
    baseURL: "http://59.110.53.228:8000/"
  },
  production: {
    // 生产环境
    baseURL: ""
  }
};

const ENV = process.env.NODE_ENV;

export default CONFIG[ENV];
