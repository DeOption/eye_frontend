import axios from "axios";
import _ from "underscore";
import QS from "qs";

import config from "./config";
import store from "../store/index";
import router from "../router/index";

const REQ_SUCCESS = 0;

const axiosInstance = axios.create(config);

axiosInstance.interceptors.request.use(
  config => {
    if (store.state.user.accessToken) {
      config.headers = _.extend(config.headers || {}, {
        Authorization: `Bearer ${store.state.user.accessToken}`
      });
    }
    if (config.data) {
      if (config.headers["content-type"] === "application/json") {
        config.data = JSON.stringify(config.data);
      } else {
        config.data = QS.stringify(config.data);
      }
    }
    return config;
  },
  error => {
    return Promise.reject(error);
  }
);

axiosInstance.interceptors.response.use(
  response => {
    if (
      response.config.skipRouteCheck ||
      (router.currentRoute &&
        router.currentRoute.name === response.config.routeName)
    ) {
      if (response.data.return_code !== REQ_SUCCESS) {
        if (typeof response.data.return_code !== "number") {
          console.log(response);
        } else if (!response.config.allowNoneZero) {
          console.log(response);
        } else {
          return response.data;
        }
      } else {
        return response.data;
      }
    }
  },
  error => {
    if (
      error.config.skipRouteCheck ||
      (router.currentRoute &&
        router.currentRoute.name === error.config.routeName)
    ) {
      if (error && (error.response || error.request)) {
        console.log(error);
        return Promise.reject();
      }
      return Promise.reject(error);
    }
    return Promise.reject();
  }
);

export default axiosInstance;
