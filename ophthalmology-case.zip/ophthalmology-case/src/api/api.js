export default {
  userLogin: {
    label: "用户登录",
    url: "user_login",
    method: "post"
  },
  userRegister: {
    label: "用户注册",
    url: "user_register",
    method: "post"
  },
  getCaseList: {
    label: "获取病例列表",
    url: "get_case_list",
    method: "get"
  },
  getCaseDetail: {
    label: "获取病例详情",
    url: "get_case_detail",
    method: "get"
  },
  submitCaseContent: {
    label: "提交病例内容",
    url: "submit_case_content",
    method: "post"
  },
  updateCaseContent: {
    label: "修改病例内容",
    url: "update_case_detail",
    method: "post"
  }
};
